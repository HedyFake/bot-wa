import { expect, it, vi } from 'vitest';
import { PDFDocument } from 'pdf-lib';
import { existingFeatureTools } from '../src/ai/existing-feature-tools.js';
import { LunaTransport } from '../src/ai/openai/luna.js';
import { ModelRouter } from '../src/ai/model-router/router.js';
import { CommandDispatcher } from '../src/admin/commands/dispatcher.js';
import { directIntent, inferIntent } from '../src/admin/commands/intent.js';
import { ReminderWorker } from '../src/modules/reminders/worker.js';
import type { PrismaClient } from '@prisma/client';
import { AdminAuthenticator } from '../src/admin/authentication/authenticator.js';
import { ConfirmationManager } from '../src/admin/authorization/confirmation.js';
import { GroupIntelligenceService } from '../src/ai/classification/group-intelligence.js';
import { AcademicCalendarService } from '../src/modules/academic/extended-modules.js';
import { FunAndUtilityService } from '../src/modules/fun/fun-utility-service.js';
import { ScheduleService } from '../src/modules/schedule/service.js';
import { MockWhatsAppProvider } from '../src/whatsapp/adapters/mock.js';
import { OutboundGate } from '../src/whatsapp/outbound/gate.js';
import { loadConfig } from '../src/config/env.js';

const now = () => new Date('2026-11-08T18:00:00Z'); // Senin, 01.00 WIB
const student = '6281234500000@c.us';
const other = '6281234500001@c.us';
async function bot(router = new ModelRouter(), fun = new FunAndUtilityService()) {
  const wa = new MockWhatsAppProvider();
  await wa.connect();
  const config = loadConfig({ OWNER_WHATSAPP: '6280000000000' });
  const dispatcher = new CommandDispatcher({ config, whatsapp: wa, router, now, startedAt: now(), schedule: new ScheduleService(),
    auth: new AdminAuthenticator({ ownerE164: config.OWNER_WHATSAPP, adminAllowlistE164: [] }), confirmations: new ConfirmationManager(),
    outbound: new OutboundGate({ provider: wa, outboundEnabled: true, dryRun: false }), intelligence: new GroupIntelligenceService(), funService: fun });
  let id = 0;
  return { wa, send: (text: string, chat = student, sender = chat) => dispatcher.handleInbound({ providerMessageId: String(++id),
    chatJid: chat, senderJid: sender, chatType: chat.endsWith('@g.us') ? 'group' : 'private', text, receivedAt: now() }) };
}

it('membatasi .note dan pengingat lokal untuk baca, hapus dan tunda, termasuk catatan lama', async () => {
  const fun = new FunAndUtilityService();
  const legacy = fun.addNote('Catatan lama', 'Khusus pembuat', student);
  delete legacy.sourceChat; // bentuk record tersimpan sebelum upgrade
  const { send } = await bot(undefined, fun);
  expect(await send('.note list', '6281234500000@s.whatsapp.net')).toContain('Catatan lama');
  expect(await send('.note list','kelas@g.us',student)).not.toContain('Catatan lama');
  await send('.note add Catatan kelompok|Ulas bab dua','kelas@g.us',student);
  expect(await send('.note list','kelas@g.us',other)).toContain('Ulas bab dua');
  expect(await send('.note del NOTE-2',other)).toContain('tidak ditemukan');
  expect(await send('.note del NOTE-2','kelas@g.us',other)).toContain('tidak ditemukan');
  expect(await send('.note list','lain@g.us',student)).not.toContain('Ulas bab dua');
  expect(await send('.note list','kelas@g.us',student)).toContain('Ulas bab dua');
  await send('.reminder add 2026-11-12 07:30|Bawa buku');
  expect(await send('.reminder list', other)).not.toContain('Bawa buku');
  expect(await send('.reminder snooze REM-1 30', other)).toContain('tidak ditemukan');
  expect(await send('.reminder del REM-1', other)).toContain('tidak ditemukan');
  expect(await send('.reminder list')).toContain('Bawa buku');
  expect(fun.listReminders()[0]?.snoozedMinutes).toBeUndefined();
});

it('menampilkan perubahan tanggal WIB akibat snooze pada .reminder dan fungsi AI', async () => {
  const fun = new FunAndUtilityService();
  const { send } = await bot(undefined, fun);
  expect(await send('.reminder add 2026-11-31 23:50|Waktu tidak valid')).toContain('Format');
  await send('.reminder add 2026-11-14 23:50|Persiapan praktikum');
  await send('.reminder snooze REM-1 20');
  const expected = new Date('2026-11-15T00:10:00+07:00').toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  expect(await send('.reminder list')).toContain(expected + ' WIB');
  const tools = existingFeatureTools({ fun, calendar: new AcademicCalendarService(), now, chat: student, sender: student,
    owner: () => false, access: () => ({ admin: false, drive: false, schedule: false }) });
  expect(await tools.find(t => t.definition.name === 'chat_reminders')!.run('{}')).toEqual([
    { id: 'REM-1', title: 'Persiapan praktikum', whenWib: expected },
  ]);
});

it('mengirim lampiran PDF, QR dan kartu jadwal lewat permintaan biasa, .ask dan mention grup', async () => {
  const { send, wa } = await bot();
  await send('.ask Buatkan PDF berjudul Laporan praktik dengan isi Hasil diskusi kelas');
  expect(wa.sent.at(-1)?.media?.mimeType).toBe('application/pdf');
  expect((await PDFDocument.load(wa.sent.at(-1)!.media!.data)).getPageCount()).toBeGreaterThan(0);
  await send('HdyBot buatkan QR untuk Kelas A','kelas@g.us',student);
  expect(wa.sent.at(-1)?.media?.data.subarray(1,4).toString()).toBe('PNG');
  await send('Buatkan kartu jadwal Senin');
  expect(wa.sent.at(-1)?.media?.mimeType).toBe('image/png');
  expect(wa.sent.at(-1)?.chatJid).toBe(student);
});

it('menggabungkan angka, kalender, tugas yang disetujui, catatan dan petunjuk menu sesuai akses', async () => {
  const fun = new FunAndUtilityService(), calendar = new AcademicCalendarService();
  const chat = 'kelas@g.us';
  const create = (title: string, sourceChat: string) => fun.addAssignment({ title, sourceChat, course: 'A', dueDateIso: '2026-11-09', createdBy: student, now: now() });
  const visible = create('Presentasi lansia',student);
  create('Belum disetujui',chat);
  const notice = fun.activeNotices().find(n => n.taskId === visible.id)!;
  fun.saveNotice({ ...notice, target: chat, share: 'sent' });
  fun.addNote('Referensi', 'Isi privat', student, chat);
  fun.addNote('Grup lain', 'Catatan lain', other, other);
  calendar.addEvent({ title: 'Ujian', dateIso: '2026-11-10', category: 'UTS', source: 'uji', verification: 'VERIFIED' });
  let admin = false;
  const tools = existingFeatureTools({ fun, calendar, now, chat, sender: student, owner: () => false,
    access: () => ({ admin, drive: false, schedule: false }) });
  const run = (name: string, args: object) => tools.find(t => t.definition.name === name)!.run(JSON.stringify(args));
  const filter = { status: 'hariini', search: '', page: 1 };
  expect(run('assignment_list',filter)).toMatchObject({ total: 1, items: [{title: 'Presentasi lansia'}] });
  expect(() => run('assignment_list',{...filter, chat: other})).toThrow();
  expect(run('chat_notes',{search:'',page:1})).toMatchObject({total:1,items:[{title:'Referensi'}]});
  expect(JSON.stringify(run('chat_notes',{search:'',page:1}))).not.toContain('Isi privat');
  expect(run('days_until',{date:'2026-11-10'})).toMatchObject({days:1});
  expect(() => run('days_until',{date:'2026-02-30'})).toThrow();
  expect(run('academic_calendar',{page:1})).toMatchObject({items:[{title:'Ujian',verification:'VERIFIED'}]});
  expect(run('math_calculator',{expression:'2^3+4'})).toEqual({ok:true,result:12});
  expect(run('unit_conversion',{value:2,from:'km',to:'m'})).toMatchObject({result:expect.stringContaining('2000')});
  expect(run('game_progress',{item:'skor'})).toEqual({xp:0});
  expect(run('game_progress',{item:'petunjuk'})).toMatchObject({hint:expect.stringContaining('Belum ada')});
  expect(run('command_guide',{search:'.logs',page:1})).toMatchObject({total:0});
  admin = true;
  expect(run('command_guide',{search:'.logs',page:1})).toMatchObject({items:[{usage:'.logs [jumlah]'}]});
  expect(run('command_guide',{search:'tanyadokumen',page:1})).toMatchObject({total:0});
  expect(run('command_guide',{search:'hitung',page:1})).toMatchObject({items:expect.arrayContaining([{category:expect.any(String),usage:'.calc <rumus>'}])});
});

it('memakai hasil fungsi lewat .ask, menunggu hasil asinkron dan menyaring rahasia sebelum dikirim ke provider', async () => {
  const fun = new FunAndUtilityService();
  fun.addReminder('2026-11-12 09:00', 'Baca buku, sandi-uji', student);
  fun.addReminder('2026-11-12 11:00', 'Privat akun lain', other);
  const exchange = vi.fn<typeof fetch>(async (_, init) => {
    const {input, tools} = JSON.parse(String(init?.body));
    expect(tools.some((t: { name: string }) => t.name === 'chat_reminders')).toBe(true);
    const last = input.at(-1);
    if (last.type !== 'function_call_output') return Response.json({status:'completed',output:[
      {type:'function_call',name:'chat_reminders',call_id:'read_1',arguments:'{}'}]});
    expect(last.output).not.toMatch(/sandi-uji|Privat akun lain/);
    const result = JSON.parse(last.output);
    expect(result.data).toHaveLength(1);
    return Response.json({status:'completed',output:[{type:'message',content:[{type:'output_text',text:result.data[0].title}]}]});
  });
  const { send } = await bot(new ModelRouter({ openai: new LunaTransport('uji', exchange, {secrets:['sandi-uji']}) }), fun);
  expect(await send('.ask Apa yang perlu kubawa?')).toContain('Baca buku, [rahasia disamarkan]');
  expect(exchange).toHaveBeenCalledTimes(2);
});

it('membaca pengingat worker memakai filter chat yang sama tanpa mengimpor atau mengubah job', async () => {
  const findMany = vi.fn().mockResolvedValue([{ id:'REM-1', text:'Praktikum', fireAt:now() }]);
  const db = { reminder:{findMany} } as unknown as PrismaClient;
  const worker = new ReminderWorker(db, new OutboundGate({provider:new MockWhatsAppProvider(),outboundEnabled:false,dryRun:true}),
    () => { throw Error('Pembacaan AI tidak boleh memulai impor'); });
  const tools = existingFeatureTools({ fun:new FunAndUtilityService(), calendar:new AcademicCalendarService(), worker, chat:student,
    now, sender:student, owner:()=>false, access:()=>({admin:false,drive:false,schedule:false}) });
  expect(await tools.find(t=>t.definition.name==='chat_reminders')!.run('{}')).toMatchObject([{ title:'Praktikum' }]);
  expect(findMany).toHaveBeenCalledWith(expect.objectContaining({ where:{targetJid:student,status:'scheduled'}, take:30 }));
});

it('memahami daftar catatan dan pengingat tanpa izin untuk menghapus melalui keputusan AI', async () => {
  expect(directIntent('bot lihat catatan saya')?.command).toBe('notes');
  expect(directIntent('tampilkan pengingat grup ini')?.command).toBe('reminders');
  const decide = (args:string) => inferIntent('tolong bantu ingat isi obrolan', new ModelRouter({
    transport:{complete:async()=>({content:JSON.stringify({command:'note',args})})},
  }));
  expect((await decide('list')).command).toBe('notes');
  expect((await decide('del NOTE-1')).command).not.toBe('notes');
});

it('menghentikan giliran tool asinkron saat batas waktu provider habis', async () => {
  const ctrl = new AbortController();
  let started!: () => void;
  const reading = new Promise<void>(resolve => { started = resolve; });
  let finish!: (text: string) => void;
  const read = new Promise<string>(resolve => { finish = resolve; });
  const fetcher = vi.fn<typeof fetch>(async () => Response.json({status:'completed',output:[
    {type:'function_call',name:'read',call_id:'late_call',arguments:'{}'}]}));
  const result = new LunaTransport('uji',fetcher).complete({ model:'gpt-6-luna', messages:[{role:'user',content:'Baca pengingat'}],
    max_tokens:100,temperature:0,top_p:1 }, ctrl.signal, { tools:[{
      definition:{name:'read',description:'Pembacaan uji',type:'function',strict:true,parameters:{}},
      run() { started(); return read; },
    }] });
  await reading;
  ctrl.abort();
  await expect(result).rejects.toMatchObject({name:'AbortError'});
  finish('Hasil terlambat');
  expect(fetcher).toHaveBeenCalledTimes(1);
});
